export interface Student {
    name: string;
    studentId: string;
  }
  